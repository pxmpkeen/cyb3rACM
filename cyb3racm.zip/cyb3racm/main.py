from flask import Flask
from models import *

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://pxmpkeen:pxmpkeen@localhost:5432/cyb3racm"

db.init_app(app)
with app.app_context():
    AbstractModel.metadata.create_all(db.engine)


if __name__ == "__main__":
    app.run(debug=True)