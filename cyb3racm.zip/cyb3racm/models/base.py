from sqlalchemy.orm import as_declarative, Mapped, mapped_column, declared_attr
from uuid import uuid4, UUID


@as_declarative()
class AbstractModel:
    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)

    @classmethod
    @declared_attr
    def __tablename__(cls) -> str:
        import re
        return re.sub(r'(?<!^)(?=[A-Z])', '_', cls.__name__).lower()