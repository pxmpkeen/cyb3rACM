from sqlalchemy import String, DateTime, Text
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime
from .base import AbstractModel


class CapturePackets(AbstractModel):
    sourceIp: Mapped[str] = mapped_column(String(30), nullable=False)
    destinationIp: Mapped[str] = mapped_column(String(30), nullable=False)
    sourcePort: Mapped[int] = mapped_column(nullable=False)
    destinationPort: Mapped[int] = mapped_column(nullable=False)
    date: Mapped[datetime | None] = mapped_column(DateTime, nullable=False, default=datetime.now)
    packet: Mapped[str] = mapped_column(Text, nullable=False)
    protocolType: Mapped[str] = mapped_column(String(10), nullable=False)

    def to_dict(self):
        return {
            'id': str(self.id),
            'sourceIp': self.sourceIp,
            'destinationIp': self.destinationIp,
            'sourcePort': self.sourcePort,
            'destinationPort': self.destinationPort,
            'date': str(self.date),
            'packet': self.packet
        }